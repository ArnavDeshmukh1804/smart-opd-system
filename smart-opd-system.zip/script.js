let count = 1;

function registerPatient() {

    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let phone = document.getElementById("phone").value;

    let patientID = "PAT" + count;

    count++;

    let patientData = {
        id: patientID,
        name: name,
        age: age,
        phone: phone
    };

    db.collection("patients")
.doc(patientID)
.set(patientData)
.then(() => {

    console.log("Patient saved to Firebase");

})
.catch((error) => {

    console.log(error);

});

    console.log("Saved:", patientData);

    document.getElementById("patientID").innerText =
        "Patient ID: " + patientID;

    QRCode.toCanvas(
        document.getElementById("qrcode"),
        patientID
    );
}
let currentPatient = null;

function searchPatient() {

    let id = document.getElementById("searchID").value;

    db.collection("patients")
    .doc(id)
    .get()
    .then((doc) => {

        if(doc.exists) {

            currentPatient = doc.data();

            document.getElementById(
                "patientDetails"
            ).innerHTML =

            `
            <h3>Patient Details</h3>

            <p><b>Name:</b> ${currentPatient.name}</p>

            <p><b>Age:</b> ${currentPatient.age}</p>

            <p><b>Phone:</b> ${currentPatient.phone}</p>
            `;

        }

        else {

            alert("Patient not found");

        }

    })

    .catch((error) => {

        console.log(error);

    });

}

function saveDiagnosis() {

    if(currentPatient == null) {

        alert("Search patient first");
        return;

    }

    let diagnosis =
        document.getElementById("diagnosis").value;

    db.collection("patients")
    .doc(currentPatient.id)
    .update({

        diagnosis: diagnosis

    })

    .then(() => {

        alert("Diagnosis Saved");

    })

    .catch((error) => {

        console.log(error);

    });

}
function onScanSuccess(decodedText, decodedResult) {

    // Put scanned patient ID in input box
    document.getElementById("searchID").value = decodedText;

    // Automatically search patient
    searchPatient();
}

// QR scanner only for doctor page

if(document.getElementById("reader")) {

    let html5QrcodeScanner = new Html5QrcodeScanner(
        "reader",
        {
            fps: 10,
            qrbox: 250
        }
    );

    html5QrcodeScanner.render(onScanSuccess);
}
let currentLabPatient = null;

function loadLabPatient() {

    let id =
        document.getElementById("labPatientID").value;

    db.collection("patients")
    .doc(id)
    .get()

    .then((doc) => {

        if(doc.exists) {

            currentLabPatient = doc.data();

            document.getElementById(
                "labPatientDetails"
            ).innerHTML =

            `
            <h3>Patient Details</h3>

            <p>Name: ${currentLabPatient.name}</p>

            <p>Age: ${currentLabPatient.age}</p>

            <p>Phone: ${currentLabPatient.phone}</p>
            `;

        }

        else {

            alert("Patient not found");

        }

    })

    .catch((error) => {

        console.log(error);

    });

}

function uploadLabReport() {

    if(currentLabPatient == null) {

        alert("Search patient first");
        return;

    }

    let report =
        document.getElementById("labReport").value;

    db.collection("patients")
    .doc(currentLabPatient.id)
    .update({

        labReport: report

    })

    .then(() => {

        alert("Lab Report Uploaded");

    })

    .catch((error) => {

        console.log(error);

    });

}